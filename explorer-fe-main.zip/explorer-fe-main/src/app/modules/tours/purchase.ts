export interface Purchase {
  authorId: number;
  tourId: number;
  tourName: string;
  touristId: number;
  price: number;
  purchaseDate: Date;
}

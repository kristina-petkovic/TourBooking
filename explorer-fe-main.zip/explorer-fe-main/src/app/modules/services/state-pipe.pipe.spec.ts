import { StatePipePipe } from './state-pipe.pipe';

describe('StatePipePipe', () => {
  it('create an instance', () => {
    const pipe = new StatePipePipe();
    expect(pipe).toBeTruthy();
  });
});

export interface Users {
  id: number;
  username: string;
  role: number;
}

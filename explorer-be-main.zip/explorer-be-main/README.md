# hospital-be

1. Instalirati Postgres
2. Ako je potrebno, u appsettings.json (HospitalAPI) promeniti username i password da odgovara bazi
3. U terminalu se pozicionirati u HospitalAPI i izvršiti komandu __dotnet ef database update__ kako bi se kreirala baza

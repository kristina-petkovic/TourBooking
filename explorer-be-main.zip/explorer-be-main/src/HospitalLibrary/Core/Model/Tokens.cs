﻿namespace HospitalLibrary.Core.Model
{
    public class Tokens
    {
        public string Token { get; set; }
    }
}
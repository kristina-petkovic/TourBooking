﻿namespace HospitalLibrary.Core.Model.Enum
{
    public enum TourStatus
    {
        Draft, Published, Archived
    }
}
﻿namespace HospitalLibrary.Core.Model.Enum
{
    public enum TourDifficulty
    {
        Easy, Medium, Hard
    }
}
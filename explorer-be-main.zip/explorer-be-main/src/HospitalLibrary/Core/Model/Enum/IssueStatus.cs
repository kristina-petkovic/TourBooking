﻿namespace HospitalLibrary.Core.Model.Enum
{
    public enum IssueStatus
    {
        Pending, Revision, Resolved, Declined
    }
}
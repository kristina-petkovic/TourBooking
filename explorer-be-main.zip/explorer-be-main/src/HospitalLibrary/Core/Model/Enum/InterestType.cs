﻿namespace HospitalLibrary.Core.Model.Enum
{
    public enum InterestType
    {
        nature, art, sport, shopping, food
    }
}
﻿namespace HospitalLibrary.Core.Model.Enum
{
    public enum Role
    {
        Tourist, Author, Admin
    }
}
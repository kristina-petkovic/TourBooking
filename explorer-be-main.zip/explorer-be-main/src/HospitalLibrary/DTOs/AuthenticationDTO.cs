﻿namespace HospitalLibrary.Core.DTOs
{
    public class AuthenticationDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}